package javaTest;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Person testPerson1 = new Person("testfirstname","testsurname","00/00/0000","testnationality", "testvisainfo");
		Boat testBoat1 = new Boat("testname","testcountry",100);
		Marina testMarina1 = new Marina("testname", "testaddress", 100);
		
		
		
		
	}

}
