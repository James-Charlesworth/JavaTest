package javaTest;

public interface Vehicle {
	
	int getSpeed();
	void accelerate();
	void deccelerate();

}
