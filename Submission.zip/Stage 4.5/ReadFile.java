package javaTest;

public class ReadFile {

}
